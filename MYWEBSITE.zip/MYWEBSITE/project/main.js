const slides = document.querySelector('.slides');
const slide = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');

let index = 0;
const lastIndex = slide.length - 1;

function moveSlider() {
  slides.style.transform = `translateX(-${index * 100}%)`;
  dots.forEach((dot) => dot.classList.remove('active'));
  dots[index].classList.add('active');
}

function nextSlide() {
  index = index === lastIndex ? 0 : index + 1;
  moveSlider();
}

function prevSlide() {
  index = index === 0 ? lastIndex : index - 1;
  moveSlider();
}

dots.forEach((dot, dotIndex) => {
  dot.addEventListener('click', () => {
    index = dotIndex;
    moveSlider();
  });
});

setInterval(nextSlide, 5000);